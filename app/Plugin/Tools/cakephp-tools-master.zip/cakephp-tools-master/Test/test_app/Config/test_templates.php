<?php
/**
 * Template strings for testing.
 */
$config = [
	'link' => '<a href="{{url}}">{{text}}</a>',
];
