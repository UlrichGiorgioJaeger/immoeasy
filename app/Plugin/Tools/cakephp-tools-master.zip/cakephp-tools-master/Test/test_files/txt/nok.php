﻿<?php

/**
 * Test BOM with umlauts like äöü
 */
class IAMNOK {
}