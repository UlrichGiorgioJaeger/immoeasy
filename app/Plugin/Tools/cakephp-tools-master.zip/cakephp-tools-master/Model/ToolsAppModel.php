<?php
App::uses('AppModel', 'Model');

class ToolsAppModel extends AppModel {

}
